# Student Records (Flutter + Cloud Firestore) - Ex. 7

## 1. One-time Firebase setup
1. Go to https://console.firebase.google.com and create a project.
2. In the project: Build > Firestore Database > Create database
   (start in TEST mode so reads/writes work for the lab).
3. Install tools (PowerShell):
       npm install -g firebase-tools
       dart pub global activate flutterfire_cli
       firebase login
   If `flutterfire` is not found, add  %LOCALAPPDATA%\Pub\Cache\bin  to PATH.

## 2. Open in VS Code and run
Open this folder in VS Code, then in the terminal (must be in the folder that contains pubspec.yaml):

    flutter create . --platforms=web,windows,android
    flutter pub get
    flutterfire configure        # pick your project + web (this overwrites lib/firebase_options.dart)
    flutter run -d chrome

## 3. For your record
Add your own students in the form, e.g.
- Priyanka | URK23CS5071
- Vinisha  | URK23CS5041
and take screenshots of the initial screen, insertion, and successful insertion.
Close and reopen the app to show that data persists.
