// Firestore needs a live Firebase project, so the app itself is tested by
// running it. This placeholder keeps `flutter test` from failing on the
// default counter test that `flutter create` would otherwise add.
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('placeholder', () {
    expect(1 + 1, 2);
  });
}
